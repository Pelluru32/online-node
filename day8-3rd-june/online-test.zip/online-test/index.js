var user = "vijay";

// module.exports.user = user;
module.exports = { user };