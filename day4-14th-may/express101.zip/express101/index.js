var expess = require("express");
var app = expess();

//------------------------------------
// app.use(expess.static(__dirname+"/public",{ index : "app.html" }));
//------------------------------------

// Default Route
app.get("/", function(req, res){
    /*
    res.write("<h1> hello from express </h1>");
    res.end();
    */
   // res.send("<h1> hello from express </h1>");
   console.log(req.url);
   res.sendFile(__dirname+"/public/app.html");
   
})

// Named Route
/* app.get("/products.html", function(req, res){
    console.log(req.url);
    res.sendFile(__dirname+"/public/products.html");
}) */

// Wildcard Route
app.get("**", function(req, res){
    console.log(req.url);
    res.sendFile(__dirname+"/public/"+req.url);
})
// REST 
// CRUD

// Create
// Read
// Update
// Delete

app.listen(3030,function(error){
    if(error){ console.log("Error ", error)}
    else{ console.log("Web server is now live on localhost:3030") }
});