var express = require("express");
let app = express();
// ---------------------------------
app.set("view engine", "pug");
// ---------------------------------
app.get("/", function(req, res){
    res.render("home",{
        companyname : "Intellipaat",
        subject : "Node Training"
    });
})
app.get("/about", function(req, res){
    res.render("about",{
        message : `
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Corrupti, sit. Odit sapiente consequatur similique expedita sed, harum ad soluta nulla repellendus illum quae, eum ipsa. Perferendis, commodi quos. Pariatur, dolorem.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, officia. Dolorem harum ducimus commodi voluptatum tempore voluptatem distinctio minima fuga obcaecati sed perferendis reiciendis eos, porro recusandae ex fugiat error.
        `
    });
})
app.get("/contact", function(req, res){
    res.render("contact",{
        message : "Contact Us between 9am to 6pm"
    });
})


app.listen(process.env.PORT || 5050, "localhost", function(err){
    if(err){ console.log("Error ", err) }
    else{ console.log("server is now live on localhost:",process.env.PORT) }
})