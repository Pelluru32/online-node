var express = require("express");
var mongoose = require("mongoose");
//--------------------------------
// module configuration
var app = express();
//--------------------------------
// middleware configuration
app.use(express.json());
//--------------------------------
// db configurations
var Schema = mongoose.Schema;
var ObjectId = Schema.ObjectId;
var url = "mongodb+srv://admin:L5vIBG12rRKlwvox@cluster0.lp2nyck.mongodb.net/onlinedb?retryWrites=true&w=majority";

var Hero = mongoose.model("Hero", Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String
}));

mongoose.connect(url)
.then( res => console.log("DB connected"))
.catch( err => console.log("Error ", err));

//--------------------------------
// routes 
app.get("/", function(req, res){
    Hero.find()
    .then( dbres => {
        res.render("home.pug", {
            herolist : dbres
        });
    } )
    .catch( error => console.log("Error ", error))
})
//--------------------------------
// web server configurations
app.listen(5050,"localhost",function(error){
    if(error){
        console.log("Error ", error);
    }else{
        console.log("Server is now live on localhost:5050");
    }
})