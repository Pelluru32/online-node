var express = require("express");
var config = require("./config.json");
var data = require("./data.json"); 
var fs = require("fs");

var app = express();
var tempdata = data;
//--------------------------------------------------------------------
// middlewares
app.use(express.urlencoded({ extended : true }));
//--------------------------------------------------------------------
// routes
var title = "Intellipaat Application";
app.get("/", function(req, res){
    res.render("home.pug",{
        title : title,
        herolist : tempdata.heroeslist
    })
})
app.post("/", function(req, res){
    // console.log(req.body);
    tempdata.heroeslist.push(req.body.htitle);
    fs.writeFile("data.json",JSON.stringify( tempdata ), function(err){
        if(err){ console.log("Error ", err) }
        else{
            res.redirect("/");
            res.end();
        }
    })
})


app.listen(config.port, config.host, function(err){
    if(err){ console.log( "Error ", err )}
    else{ console.log("Server is now live on "+config.host+":"+process.env.PORT)}
})